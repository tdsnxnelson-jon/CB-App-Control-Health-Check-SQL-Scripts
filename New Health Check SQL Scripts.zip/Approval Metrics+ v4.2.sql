use das
SET STATISTICS TIME OFF
GO
-- use the Bit9 database
DECLARE @myStartDate AS Date;
SET @myStartDate = DATEADD(week, -4, GETDATE());
 
-- drop any temp tables in case we left them around
IF OBJECT_ID('tempdb..#myBit9ComputersInfo') IS NOT NULL drop table #myBit9ComputersInfo;
IF OBJECT_ID('tempdb..#myBit9ComputersGlobal') IS NOT NULL drop table #myBit9ComputersGlobal;
IF OBJECT_ID('tempdb..#myBit9ComputersGlobalRep') IS NOT NULL drop table #myBit9ComputersGlobalRep;
IF OBJECT_ID('tempdb..#myBit9ComputersGlobalTD') IS NOT NULL drop table #myBit9ComputersGlobalTD;
IF OBJECT_ID('tempdb..#myBit9ComputersLocal') IS NOT NULL drop table #myBit9ComputersLocal;
IF OBJECT_ID('tempdb..#myBit9ComputersFiltered') IS NOT NULL drop table #myBit9ComputersFiltered;
IF OBJECT_ID('tempdb..#myBit9ComputersInfo') IS NOT NULL drop table #myBit9ComputersInfo;
IF OBJECT_ID('tempdb..#myBit9ComputersInitialized') IS NOT NULL drop table #myBit9ComputersInitialized;
IF OBJECT_ID('tempdb..#myBit9ComputersPending') IS NOT NULL drop table #myBit9ComputersPending;
IF OBJECT_ID('tempdb..#myBit9ComputersTotal') IS NOT NULL drop table #myBit9ComputersTotal;
IF OBJECT_ID('tempdb..#myBit9ComputersUnapprovedEvents') IS NOT NULL drop table #myBit9ComputersUnapprovedEvents;

-- get basic info for all live computers from the ExComputers table and put in temp table
select
      h.host_id as 'Computer_Id',
      h.display_hostname as 'Computer',
      hs.Connected as 'Connected',
      CONVERT(VARCHAR(10), h.bit9_version_major) + '.' + CONVERT(VARCHAR(10), h.bit9_version_minor) + '.' + CONVERT(VARCHAR(10), h.bit9_version_point) + '.' + CONVERT(VARCHAR(10), h.bit9_version_build) + (CASE WHEN h.bit9_version_debug = 1 THEN 'DEBUG' ELSE '' END) AS 'Agent_Version',
      hs.last_poll_date AS 'Poll_Date',
      (SELECT MIN(Date_Created) from dbo.antibody_instance_groups as aig with (nolock) 
		where aig.host_id = h.host_id and isnull(aig.type,0) = 0 and aig.antibody_id = 0)
		as 'Initialization_Date',
	  ISNULL(pl.name, N'Unknown') AS 'Platform',
      hg.name as 'Policy',
      CASE 
		WHEN (hs.synch_flags&1)=1 OR ab_cache_size<ab_queue_size OR ab_cache_size<=0 OR (h.refresh_flags&1) = 1 THEN 0
		WHEN ab_queue_size<=0 THEN 100
		ELSE 100 - (100*ab_queue_size + ab_cache_size/2)/ab_cache_size
	  END AS 'Synch_Percent',
      dbo.GetPolicyStatus(hs.synch_flags, hs.debug_flags, h.host_group_id, 0) AS 'Policy_Status'
into
      #myBit9ComputersInfo
from
      dbo.hostmain as h with (nolock)
	  Left Join dbo.host_groups as hg with (nolock) on hg.host_group_id = h.host_group_id
	  LEFT JOIN dbo.host_state AS hs WITH (nolock) ON hs.host_id = h.host_id
	  --Left Join dbo.antibody_instance_groups as aig with (nolock) on aig.host_id = h.host_id
	  LEFT JOIN dbo.operating_systems os WITH (nolock) ON h.operating_system_id = os.operating_system_id
	  LEFT JOIN dbo.platforms pl WITH (nolock) ON os.platform_id = pl.platform_id
where
      h.deleted = 0;
      
-- get for each computer a count of all file instances
-- that are globally approved and put in temp table
select
	  FI.host_id,
      COUNT(*) as 'Global'
into
      #myBit9ComputersGlobal
from
      dbo.antibody_instances FI with (nolock)
      left join dbo.antibodies FC with (nolock) on FI.antibody_id = FC.antibody_id 
      left join dbo.antibody_states GS with (nolock) on FC.antibody_id = GS.antibody_id
where
      GS.simple_state = 'Approved'
--      and FI.local_state IN (1, 4, 7, 8, 11, 12) -- added to fix db inconsistency
group by
      FI.host_id;

-- get for each computer a count of all file instances
-- that are globally approved by reputation and put in temp table
select
      FI.host_id,
      COUNT(*) as 'GlobalRep'
into
      #myBit9ComputersGlobalRep
from
      dbo.antibody_instances FI with (nolock)
      left join dbo.antibodies FC with (nolock) on FI.antibody_id = FC.antibody_id 
      left join dbo.antibody_states GS with (nolock) on FC.antibody_id = GS.antibody_id
where
      gs.simple_state = 'Approved' and
      gs.state_source = 'Reputation'
--      and FI.Local_State = 'Approved' -- added to fix db inconsistency
group by
      FI.host_id; 
-- get for each computer a count of all file instances
-- that are globally approved by Trusted Directory and put in temp table
select
      FI.host_id,
      COUNT(*) as 'GlobalTD'
into
      #myBit9ComputersGlobalTD
from
      dbo.antibody_instances FI with (nolock)
      left join dbo.antibodies FC with (nolock) on FI.antibody_id = FC.antibody_id 
      left join dbo.antibody_states GS with (nolock) on FC.antibody_id = GS.antibody_id
where
      gs.simple_state = 'Approved' and
      gs.state_source = 'Trusted Directory'
--      and FI.Local_State = 'Approved' -- added to fix db inconsistency
group by
      FI.host_id;

-- get for each computer a count of all file instances that 
-- are locally but not globally approved and were not found 
-- at initialization and put in temp table
select
      FI.host_id,
      COUNT(*) as 'Local'
into
      #myBit9ComputersLocal
from
      dbo.antibody_instances FI with (nolock)
	  left join dbo.antibodies FC with (nolock) on FI.antibody_id = FC.antibody_id 
      left join dbo.antibody_states GS with (nolock) on FC.antibody_id = GS.antibody_id      
      left join dbo.antibody_instance_groups FG with (nolock) on FI.antibody_instance_group_id = FG.antibody_instance_group_id
where
	  gs.simple_state <> 'Approved' 
	  and FI.local_state IN (1, 4, 7, 8, 11, 12)
	  and isnull(FG.type,-1) <> 0
group by
      FI.host_id;

-- get for each computer a count of all file instances that 
-- are locally but not globally approved and were YES found 
-- at initialization and pass filter and put in temp table
select
      FI.host_id,
      COUNT(*) as 'Filtered'
into
      #myBit9ComputersFiltered
from
      dbo.antibody_instances FI with (nolock)
	  left join dbo.antibodies FC with (nolock) on FI.antibody_id = FC.antibody_id 
      left join dbo.antibody_states GS with (nolock) on FC.antibody_id = GS.antibody_id      
      left join dbo.antibody_instance_groups FG with (nolock) on FI.antibody_instance_group_id = FG.antibody_instance_group_id
      left join dbo.paritycenter_antibody_metadata FT with (nolock) on FI.antibody_id = FT.antibody_id
where
	  gs.simple_state <> 'Approved' 
	  and FI.local_state IN (1, 4, 7, 8, 11, 12)
	  and isnull(FG.type,-1) = 0
	  and (FC.publisher in (select publisher_id from dbo.TrustedPublishersGUI where State = 'Approved')  
	  or isnull(FT.threat,999) = 0 or
	  FT.trust > .5)
group by
      FI.host_id;

-- get for each computer a count of all file instances that 
-- are locally but not globally approved and were YES found 
-- at initialization and put in temp table
select
      FI.host_id,
      COUNT(*) as 'Init'
into
      #myBit9ComputersInitialized
from
      dbo.antibody_instances FI with (nolock)
      left join dbo.antibody_states GS with (nolock) on FI.antibody_id = GS.antibody_id      
      left join dbo.antibody_instance_groups FG with (nolock) on FI.antibody_instance_group_id = FG.antibody_instance_group_id
where
	  gs.simple_state <> 'Approved' 
	  and FI.local_state IN (1, 4, 7, 8, 11, 12)
	  and isnull(FG.type,-1) = 0
group by
      FI.host_id;
 
-- get for each computer a count of all file instances that 
-- are locally Pending
select
      FI.host_id,
      COUNT(*) as 'Pending'
into
      #myBit9ComputersPending
from
      dbo.antibody_instances FI with (nolock)
	  left join dbo.antibodies FC with (nolock) on FI.antibody_id = FC.antibody_id
where
	  FI.local_state not IN (1, 4, 7, 8, 11, 12)
group by
      FI.host_id; 

-- get a list of the total number of files on each computer
-- an put in temp table
select
      FI.host_id,
      COUNT(*) as 'Total'
into
      #myBit9ComputersTotal
from
      dbo.antibody_instances FI with (nolock)
group by
      FI.host_id;

-- get a list of the total number of unapproved events on each computer
-- an put in temp table
select e.host_id, count(distinct e.event_id) as 'Total'
into
      #myBit9ComputersUnapprovedEvents
from 
	dbo.events e with (nolock)
	left join dbo.filenames pf with (nolock) on e.filename_id = pf.filename_id
	left join dbo.pathnames pp with (nolock) on e.pathname_id = pp.pathname_id
	left join dbo.filenames ff with (nolock) on e.filename_id = ff.filename_id
	left join dbo.pathnames fp with (nolock) on e.pathname_id = fp.pathname_id
	left join dbo.antibody_instances fi WITH (NOLOCK) on fi.antibody_id = e.antibody_id and fi.host_id = e.host_id
	left join dbo.antibodies ab WITH (NOLOCK) on ab.antibody_id = e.antibody_id and ab.host_id = e.host_id
	left join dbo.antibody_states abstate with (nolock) on abstate.antibody_id = ab.antibody_id
	left join dbo.publishers pub with (nolock) on ab.publisher = pub.publisher_id
where 
	e.subtype = 1003
	and ((fi.local_flags&16384) = 16384 or ab.first_execution_date is not null)
	and e.time > @myStartDate
	AND isnull(abstate.state_source,'') <> 'Reputation'
	AND isnull(pub.simple_state,'') <> 'Approved'
	and not fp.pathname like '\\%'
	and LEFT(e.param1,25) in ('DiscoveredBy[Kernel:Creat','DiscoveredBy[Kernel:MmapW','DiscoveredBy[Kernel:Renam','DiscoveredBy[Kernel:Write','DiscoveredBy[MSICallback]')
group by e.host_id

-- now merge contents from all temp tables and output
select
      #myBit9ComputersInfo.Computer_Id as 'Computer ID',
      #myBit9ComputersInfo.Computer as 'Computer Name',
      #myBit9ComputersInfo.Connected as 'Connected',
      #myBit9ComputersInfo.Agent_Version as 'Agemt Version',
      #myBit9ComputersInfo.Poll_Date as 'Last Polled',
      #myBit9ComputersInfo.Initialization_Date as 'Initialized',
      #myBit9ComputersInfo.Platform as 'Platform',
      #myBit9ComputersInfo.Policy as 'Policy',
      #myBit9ComputersInfo.Synch_Percent as '%Sync',
      #myBit9ComputersInfo.Policy_Status as 'ConfigStatus',
      isnull(#myBit9ComputersGlobal.Global, 0) as '#Global Approval',
      isnull(#myBit9ComputersGlobalTD.GlobalTD, 0) as '#Global TD',
      case isnull(#myBit9ComputersGlobalRep.GlobalRep, 0)
		when 0
			then '0' 
			else isnull(#myBit9ComputersGlobalRep.GlobalRep, 0) - (isnull(#myBit9ComputersGlobalTD.GlobalTD, 0) - (isnull(#myBit9ComputersGlobal.Global, 0) - isnull(#myBit9ComputersGlobalRep.GlobalRep, 0)))
	  end as '#Global Rep',
      case isnull(#myBit9ComputersGlobalRep.GlobalRep, 0)
		when 0
			then isnull(#myBit9ComputersGlobal.Global, 0) - isnull(#myBit9ComputersGlobalTD.GlobalTD, 0) 
			else isnull(#myBit9ComputersGlobal.Global, 0) - isnull(#myBit9ComputersGlobalTD.GlobalTD, 0) - (isnull(#myBit9ComputersGlobalRep.GlobalRep, 0) - (isnull(#myBit9ComputersGlobalTD.GlobalTD, 0) - (isnull(#myBit9ComputersGlobal.Global, 0) - isnull(#myBit9ComputersGlobalRep.GlobalRep, 0))))
	  end as '#Global Oth',
      isnull(#myBit9ComputersInitialized.Init, 0) as '#Local Approval: Initialization',
      isnull(#myBit9ComputersInitialized.Init, 0) - isnull(#myBit9ComputersFiltered.Filtered, 0) as '#Local Approval: UnValidated',
      isnull(#myBit9ComputersFiltered.Filtered, 0) as '#Local Approval: Policy',
      isnull(#myBit9ComputersLocal.Local, 0) as '#Local Approval: Rule',
      isnull(#myBit9ComputersPending.Pending, 0) as '#Unapproved',
      isnull(#myBit9ComputersTotal.Total, 0) as '#Files',
      isnull(#myBit9ComputersUnapprovedEvents.Total, 0) as '#Unapprove Events',
      convert(decimal(38,10), 
      (cast(isnull(#myBit9ComputersGlobal.Global, 0) as float) +
      cast(isnull(#myBit9ComputersInitialized.Init, 0) as float) +
      cast(isnull(#myBit9ComputersLocal.Local, 0) as float)) / cast(isnull(#myBit9ComputersTotal.Total, 0) as float)) as '%Whitelist',
      convert(decimal(38,10), 
      cast(isnull(#myBit9ComputersGlobal.Global, 0) as float) / cast(isnull(#myBit9ComputersTotal.Total, 0) as float)) as '%Global'
from
      #myBit9ComputersInfo with (nolock)
      Left join            
			#myBit9ComputersGlobal with (nolock)
      on
            #myBit9ComputersInfo.Computer_Id = #myBit9ComputersGlobal.host_id
      Left join            
			#myBit9ComputersGlobalRep with (nolock)
      on
            #myBit9ComputersInfo.Computer_Id = #myBit9ComputersGlobalRep.host_id
      Left join            
			#myBit9ComputersGlobalTD with (nolock)
      on
            #myBit9ComputersInfo.Computer_Id = #myBit9ComputersGlobalTD.host_id
      left join
            #myBit9ComputersLocal with (nolock)
      on
            #myBit9ComputersInfo.Computer_Id = #myBit9ComputersLocal.host_id
      left join
			#myBit9ComputersFiltered with (nolock)
      on
            #myBit9ComputersInfo.Computer_Id = #myBit9ComputersFiltered.host_id
      left join
            #myBit9ComputersInitialized with (nolock)
      on
            #myBit9ComputersInfo.Computer_Id = #myBit9ComputersInitialized.host_id
      left join
            #myBit9ComputersPending with (nolock)
      on
            #myBit9ComputersInfo.Computer_Id = #myBit9ComputersPending.host_id
      left join
            #myBit9ComputersTotal with (nolock)
      on
            #myBit9ComputersInfo.Computer_Id = #myBit9ComputersTotal.host_id
      left join
            #myBit9ComputersUnapprovedEvents with (nolock)
      on
            #myBit9ComputersInfo.Computer_Id = #myBit9ComputersUnapprovedEvents.host_id
where isnull(#myBit9ComputersTotal.Total, 0) > 0
order by
      convert(decimal(38,10), 
      cast(isnull(#myBit9ComputersGlobal.Global, 0) as float) / cast(isnull(#myBit9ComputersTotal.Total, 0) as float));
 
-- clean up temp tables
IF OBJECT_ID('tempdb..#myBit9ComputersInfo') IS NOT NULL drop table #myBit9ComputersInfo;
IF OBJECT_ID('tempdb..#myBit9ComputersGlobal') IS NOT NULL drop table #myBit9ComputersGlobal;
IF OBJECT_ID('tempdb..#myBit9ComputersGlobalRep') IS NOT NULL drop table #myBit9ComputersGlobalRep;
IF OBJECT_ID('tempdb..#myBit9ComputersGlobalTD') IS NOT NULL drop table #myBit9ComputersGlobalTD;
IF OBJECT_ID('tempdb..#myBit9ComputersLocal') IS NOT NULL drop table #myBit9ComputersLocal;
IF OBJECT_ID('tempdb..#myBit9ComputersFiltered') IS NOT NULL drop table #myBit9ComputersFiltered;
IF OBJECT_ID('tempdb..#myBit9ComputersInfo') IS NOT NULL drop table #myBit9ComputersInfo;
IF OBJECT_ID('tempdb..#myBit9ComputersInitialized') IS NOT NULL drop table #myBit9ComputersInitialized;
IF OBJECT_ID('tempdb..#myBit9ComputersPending') IS NOT NULL drop table #myBit9ComputersPending;
IF OBJECT_ID('tempdb..#myBit9ComputersTotal') IS NOT NULL drop table #myBit9ComputersTotal;
IF OBJECT_ID('tempdb..#myBit9ComputersUnapprovedEvents') IS NOT NULL drop table #myBit9ComputersUnapprovedEvents;

SET STATISTICS TIME off
GO
